package com.example.entity;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class RetailManager {
    public static void main(String[] args) {
        // Create the SessionFactory based on your hibernate.cfg.xml
        SessionFactory factory = new Configuration()
                .configure("hibernate.cfg.xml")
                .addAnnotatedClass(Product.class)
                .buildSessionFactory();

        try {
            // TASK 3: Insert multiple Product records
            System.out.println("Inserting products...");
            saveProduct(factory, new Product("Laptop", "High-end gaming laptop", 1500.0, 10));
            saveProduct(factory, new Product("Smartphone", "Latest model with AI features", 800.0, 25));
            saveProduct(factory, new Product("Headphones", "Noise-cancelling wireless", 200.0, 50));

            // TASK 4: Retrieve a product using its ID (Let's check ID 1)
            int productId = 1;
            Product myProduct = getProduct(factory, productId);
            if (myProduct != null) {
                System.out.println("Retrieved: " + myProduct.getName() + " - " + myProduct.getDescription());
            }

            // TASK 5: Update the price or quantity
            System.out.println("Updating product price...");
            updateProduct(factory, productId, 1400.0, 12);

            // TASK 6: Delete a product record by ID (e.g., if discontinued)
            // System.out.println("Deleting product...");
            // deleteProduct(factory, 2); 

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            factory.close();
        }
    }

    // --- CRUD HELPER METHODS ---

    public static void saveProduct(SessionFactory factory, Product p) {
        Session session = factory.getCurrentSession();
        session.beginTransaction();
        session.save(p);
        session.getTransaction().commit();
    }

    public static Product getProduct(SessionFactory factory, int id) {
        Session session = factory.getCurrentSession();
        session.beginTransaction();
        Product p = session.get(Product.class, id);
        session.getTransaction().commit();
        return p;
    }

    public static void updateProduct(SessionFactory factory, int id, double price, int qty) {
        Session session = factory.getCurrentSession();
        session.beginTransaction();
        Product p = session.get(Product.class, id);
        if (p != null) {
            p.setPrice(price);
            p.setQuantity(qty);
        }
        session.getTransaction().commit();
    }

    public static void deleteProduct(SessionFactory factory, int id) {
        Session session = factory.getCurrentSession();
        session.beginTransaction();
        Product p = session.get(Product.class, id);
        if (p != null) session.delete(p);
        session.getTransaction().commit();
    }
}