package com.example.util;

public class HibernateUtil {

}
